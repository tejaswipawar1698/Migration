package org.example.repository.secondary;

import org.example.entity.ClientExternalRoundMapping;
import org.example.entity.ClientExternalRoundMapping;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SecondaryClientExternalRoundMappingRepository extends JpaRepository<ClientExternalRoundMapping, Long> {


}
